function isProduction() {
    // TODO refactor this ugly approach
    return window.location.host === 'audio-network.rypula.pl';
}
